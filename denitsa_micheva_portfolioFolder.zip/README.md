# Denitsa Micheva — Portfolio

Static portfolio prepared for GitHub Pages.

## Publish with GitHub Pages
1. Create a new public GitHub repository.
2. Upload `index.html` and the entire `images` folder, keeping this structure.
3. In the repository open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.

The site uses relative image paths, so keep the `images` folder next to `index.html`.

## CV
The downloadable CV is stored at `assets/Denitsa_Micheva_CV.docx`.
